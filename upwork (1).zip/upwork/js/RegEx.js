function valid_credit_card(value) {
    if(!value)
    {
        return false;
    }
    // accept only digits, dashes or spaces
    if (/[^0-9-\s]+/.test(value)) return false;

    // The Luhn Algorithm. It's so pretty.
    var nCheck = 0, nDigit = 0, bEven = false;
    value = value.replace(/\D/g, "");

    for (var n = value.length - 1; n >= 0; n--) {
        var cDigit = value.charAt(n),
            nDigit = parseInt(cDigit, 10);

        if (bEven) {
            if ((nDigit *= 2) > 9) nDigit -= 9;
        }

        nCheck += nDigit;
        bEven = !bEven;
    }

    return (nCheck % 10) == 0;
}


function ValidateCreditCardNumber() {
    var cards =['visa','mastercard','AE','Discover','JSB'];

     for  (row in cards){
         var card =  document.getElementById(cards[row]);
         var check_class = card.classList.contains('check_card');
         if (check_class != null && check_class) {
             card.classList.remove("check_card");
         }
     }

    var ccNum = document.getElementById("cardNum").value;

    var luhn = valid_credit_card(ccNum);

    if (!luhn) {
        document.getElementById("luhn").innerHTML = 'NO VALID';
        document.getElementById("luhn").style.color = "red";
    }
    else{
        document.getElementById("luhn").innerHTML = 'VALID';
        document.getElementById("luhn").style.color = "green";
    }


        var visaRegEx = /^(?:4[0-9]{12}(?:[0-9]{3})?)$/;
        var mastercardRegEx = /^(?:5[1-5][0-9]{14})$/;
        var amexpRegEx = /^(?:3[47][0-9]{13})$/;
        var discovRegEx = /^(?:6(?:011|5[0-9][0-9])[0-9]{12})$/;
        var JCBRegEx = /^(?:2131|1800|35\d{3})\d{11}$/;
        var isValid = false;

        if (visaRegEx.test(ccNum)) {
            isValid = 'Visa';
            var card =  document.getElementById("visa");
            card.classList.add("check_card");

        } else if (mastercardRegEx.test(ccNum)) {
            isValid = 'MasterCard';
            var card =  document.getElementById("mastercard");
            card.classList.add("check_card");
        } else if (amexpRegEx.test(ccNum)) {
            var card =  document.getElementById("AE");
            card.classList.add("check_card");
            isValid = 'American Express';
        } else if (discovRegEx.test(ccNum)) {
            var card =  document.getElementById("Discover");
            card.classList.add("check_card");
            isValid = 'Discov';
        } else if (JCBRegEx.test(ccNum)) {
            var card =  document.getElementById("JSB");
            card.classList.add("check_card");
            isValid = 'JCB';
        }else{
            isValid = false
        }


        if (isValid) {
            document.getElementById("type").innerHTML = isValid;
            document.getElementById("Number").innerHTML = 'VALID';
            document.getElementById("type").style.color = "green";
            document.getElementById("Number").style.color = "green";

        } else {
            document.getElementById("type").innerHTML = 'NO VALID ';
            document.getElementById("Number").innerHTML = 'NO VALID';
            document.getElementById("type").style.color = "red";
            document.getElementById("Number").style.color = "red";

        }


  }
